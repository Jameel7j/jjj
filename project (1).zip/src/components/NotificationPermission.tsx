'use client';

import { useEffect, useState } from 'react';
import { requestNotificationPermission, useNotificationListener } from '@/lib/firebase/messaging';
import { useToast } from '@/hooks/use-toast';
import { Button } from './ui/button';

export function NotificationPermission() {
  const { toast } = useToast();
  const [permission, setPermission] = useState('default');
  
  // Custom hook to listen for incoming messages, only if permission is granted
  useNotificationListener(permission === 'granted');

  useEffect(() => {
    // This check ensures the code runs only on the client
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const handlePermissionRequest = async () => {
    // requestNotificationPermission should already handle being client-side, but this is an extra safeguard
    if (typeof window === 'undefined') return;

    const token = await requestNotificationPermission();
    if (token) {
      toast({
        title: 'شكراً لك!',
        description: 'ستتلقى الآن إشعارات منا.',
      });
      setPermission('granted');
    } else {
      toast({
        title: 'تم رفض الإذن',
        description: 'لن تتمكن من استقبال الإشعارات. يمكنك تغيير هذا من إعدادات المتصفح.',
        variant: 'destructive',
      });
      setPermission('denied');
    }
  };

  // Don't render anything if permission is already granted or denied
  if (permission !== 'default') {
    return null;
  }

  return (
    <div className="fixed bottom-20 left-4 z-50 rounded-lg border bg-background p-4 shadow-lg">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-bold">تفعيل الإشعارات</h3>
          <p className="text-sm text-muted-foreground">اسمح لنا بإرسال آخر العروض والتحديثات.</p>
        </div>
        <Button onClick={handlePermissionRequest}>
          تفعيل
        </Button>
      </div>
    </div>
  );
}
